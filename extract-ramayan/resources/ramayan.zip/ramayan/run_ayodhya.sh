#!/bin/bash

for i in {1..117}
do
	download_url="https://valmikiramayan.net/utf8/ayodhya/sarga$i/ayodhyasans$i.htm"
	echo $download_url	
	curl $download_url > ayodhya/ayodhyasans$i.htm
done

