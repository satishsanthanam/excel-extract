#!/bin/bash

for i in {1..67}
do
	download_url="https://valmikiramayan.net/utf8/kish/sarga$i/kishkindhasans$i.htm"
	echo $download_url	
	curl $download_url > ramayan/kishkindha/kishkindhasans$i.htm
done

