#!/bin/bash

for i in {1..128}
do
	download_url="https://valmikiramayan.net/utf8/yuddha/sarga$i/yuddhasans$i.htm"
	echo $download_url	
	curl $download_url > ramayan/yuddha/yuddhasans$i.htm
done

