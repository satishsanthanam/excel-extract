#!/bin/bash

for i in {1..75}
do
	download_url="https://valmikiramayan.net/utf8/aranya/sarga$i/aranyasans$i.htm"
	echo $download_url	
	curl $download_url > aranya/aranyasans$i.htm
done

