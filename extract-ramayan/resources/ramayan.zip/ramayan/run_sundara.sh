#!/bin/bash

for i in {1..68}
do
	download_url="https://valmikiramayan.net/utf8/sundara/sarga$i/sundarasans$i.htm"
	echo $download_url	
	curl $download_url > ramayan/sundara/sundarasans$i.htm
done

